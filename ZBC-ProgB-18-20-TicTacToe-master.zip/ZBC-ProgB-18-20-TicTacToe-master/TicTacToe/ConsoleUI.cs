﻿using System;

namespace TicTacToe
{
    class ConsoleUI
    {
    }
}
