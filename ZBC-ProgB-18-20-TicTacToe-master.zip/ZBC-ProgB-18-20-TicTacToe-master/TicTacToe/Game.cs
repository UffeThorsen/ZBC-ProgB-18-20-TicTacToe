﻿
namespace TicTacToe
{
    class Game
    {
        //int der hjælper med tur-bestemmelse. Denne int vil enten være 1 eller 2. Dette indikerer spiller 1's tur og spiller 2's tur.
        int hvisTur = 1;

        //Bool der skal blive True hvis kryds vinder. Kryds har turen 1
        bool harKrydsVundet = false;

        //Bool der skal blive true hvis bolle vinder. Bolle har tur 2
        bool harBolleVundet = false;

        Board spillebraet = new Board();

        //Basicly hvad man gør på en tur
        static void Tur ()
        {
            Board.Place();
            Board.ThreeInARow(hvisTur);
            if (Board.ThreeInARow == True)
            {
                if (hvisTur == 1)
                {
                    harKrydsVundet == true;
                }
                else if (hvisTur == 2)
                {
                    harBolleVundet == true;
                }
            }
            Turskift();
        }

        //Skifter tur
        static void Turskift()
        {
            if (hvisTur == 1)
            {
                hvisTur++;
            }
            else if (hvisTur == 2)
            {
                hvisTur--;
            }
        }
    }
}
